package com.example.multichest;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Holder custom: satu-satunya penanda GUI MultiChest. */
public final class MultiChestHolder implements InventoryHolder {

    public static final int GUI_SIZE = 54;
    public static final int ITEM_SLOTS = 45;
    public static final int PREVIOUS_SLOT = 45;
    public static final int INFO_SLOT = 49;
    public static final int NEXT_SLOT = 53;

    private static final int MAX_LORE_ENTRIES = 6;

    private final MultiChestPlugin plugin;
    private final StoredChest chest;
    private final int page;
    private final Inventory inventory;

    public MultiChestHolder(MultiChestPlugin plugin, StoredChest chest, int page) {
        this.plugin = plugin;
        this.chest = chest;
        this.page = Math.max(0, page);
        this.inventory = Bukkit.createInventory(this, GUI_SIZE,
                Component.text("Multi Chest - Halaman " + (this.page + 1)));
        render();
    }

    public StoredChest getChest() {
        return chest;
    }

    public int getPage() {
        return page;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void render() {
        int first = page * ITEM_SLOTS;
        for (int i = 0; i < ITEM_SLOTS; i++) {
            inventory.setItem(i, buildDisplay(first + i));
        }
        int pages = plugin.getPageCount(chest);
        inventory.setItem(PREVIOUS_SLOT, button(Material.ARROW, "Halaman Sebelumnya", null));
        inventory.setItem(INFO_SLOT, button(Material.PAPER, "Halaman " + (page + 1),
                "Dari " + pages + " halaman"));
        inventory.setItem(NEXT_SLOT, button(Material.ARROW, "Halaman Berikutnya", null));
    }

    /** Memperbarui satu slot virtual saja (jika berada di halaman ini). */
    public void refresh(int index) {
        int local = index - page * ITEM_SLOTS;
        if (local < 0 || local >= ITEM_SLOTS) return;
        inventory.setItem(local, buildDisplay(index));
    }

    private ItemStack button(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(line(name, NamedTextColor.YELLOW));
        if (lore != null) meta.lore(List.of(line(lore, NamedTextColor.GRAY)));
        plugin.markDisplay(meta);
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildDisplay(int index) {
        SlotData slot = chest.getSlot(index);
        if (slot == null || slot.isEmpty()) return null;

        ItemStackData main = slot.getLargestReadable();
        ItemStack icon;
        if (main == null) {
            icon = new ItemStack(Material.BARRIER);
        } else {
            icon = main.createStack((int) Math.max(1L, Math.min(64L, main.getAmount())));
        }

        ItemMeta meta = icon.getItemMeta();
        if (meta == null) return icon;
        if (main == null) meta.displayName(line("Item tidak terbaca", NamedTextColor.RED));

        List<Component> lore = new ArrayList<>();
        List<Component> original = meta.lore();
        if (original != null) lore.addAll(original);

        lore.add(Component.empty());
        lore.add(line("Total: " + slot.getTotal() + " / " + plugin.getMaxPerSlot(), NamedTextColor.GRAY));

        List<ItemStackData> entries = slot.getItems();
        int shown = 0;
        for (ItemStackData data : entries) {
            if (shown >= MAX_LORE_ENTRIES) {
                lore.add(line("... +" + (entries.size() - MAX_LORE_ENTRIES) + " jenis lain",
                        NamedTextColor.DARK_GRAY));
                break;
            }
            lore.add(entryLine(data));
            shown++;
        }

        lore.add(Component.empty());
        lore.add(line("Klik kiri: ambil semua", NamedTextColor.GREEN));
        lore.add(line("Klik kanan: ambil setengah", NamedTextColor.GREEN));
        lore.add(line("Klik dengan item: simpan", NamedTextColor.GREEN));

        meta.lore(lore);
        plugin.markDisplay(meta);
        icon.setItemMeta(meta);
        return icon;
    }

    private Component entryLine(ItemStackData data) {
        Component name;
        if (data.isReadable()) {
            name = Component.translatable(data.getPrototype().getType().translationKey(), NamedTextColor.WHITE);
        } else {
            name = Component.text("(tidak terbaca)", NamedTextColor.RED);
        }
        return Component.text("• ", NamedTextColor.DARK_GRAY)
                .append(Component.text(data.getAmount() + "x ", NamedTextColor.YELLOW))
                .append(name)
                .decoration(TextDecoration.ITALIC, false);
    }

    private static Component line(String text, NamedTextColor color) {
        return Component.text(text, color).decoration(TextDecoration.ITALIC, false);
    }
}
