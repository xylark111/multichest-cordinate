package com.example.multichest;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class ChestListener implements Listener {

    private static final BlockFace[] HORIZONTAL = {
            BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };

    private final MultiChestPlugin plugin;

    public ChestListener(MultiChestPlugin plugin) {
        this.plugin = plugin;
    }

    // ================================================================== membuka chest

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.CHEST) return;

        StoredChest chest = plugin.getChest(block);
        if (chest == null) return; // chest vanilla: tidak disentuh sama sekali

        Player player = event.getPlayer();
        if (player.isSneaking() && event.hasItem()) return; // biarkan vanilla (menaruh block)

        event.setCancelled(true);
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (player.getGameMode() == GameMode.SPECTATOR) return;
        plugin.openGui(player, chest, 0);
    }

    // ================================================================== klik GUI

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof MultiChestHolder holder)) return;

        if (!(event.getWhoClicked() instanceof Player player)) {
            event.setCancelled(true);
            return;
        }

        int raw = event.getRawSlot();
        InventoryAction action = event.getAction();

        // Klik di area GUI: selalu dibatalkan, diproses manual.
        if (raw >= 0 && raw < top.getSize()) {
            event.setCancelled(true);
            handleGuiClick(event, player, holder, raw);
            return;
        }

        if (raw < 0) return; // klik di luar window (drop cursor vanilla)

        // Klik di inventory pemain saat GUI terbuka.
        if (action == InventoryAction.COLLECT_TO_CURSOR) {
            event.setCancelled(true); // double click bisa menarik item tampilan GUI
        } else if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            event.setCancelled(true);
            quickDeposit(event, player, holder);
        }
    }

    /** Pengaman terakhir: jika plugin lain meng-uncancel klik GUI, batalkan lagi. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onClickGuard(InventoryClickEvent event) {
        if (event.isCancelled()) return;
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof MultiChestHolder)) return;

        int raw = event.getRawSlot();
        InventoryAction action = event.getAction();
        if ((raw >= 0 && raw < top.getSize())
                || action == InventoryAction.COLLECT_TO_CURSOR
                || action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder(false) instanceof MultiChestHolder)) return;
        int size = top.getSize();
        for (int raw : event.getRawSlots()) {
            if (raw < size) {
                event.setCancelled(true);
                return;
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onOpen(InventoryOpenEvent event) {
        if (event.getInventory().getHolder(false) instanceof MultiChestHolder holder) {
            plugin.trackOpen(holder);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder(false) instanceof MultiChestHolder holder) {
            plugin.trackClose(holder);
        }
    }

    private void handleGuiClick(InventoryClickEvent event, Player player, MultiChestHolder holder, int raw) {
        ClickType click = event.getClick();
        if (click != ClickType.LEFT && click != ClickType.RIGHT
                && click != ClickType.SHIFT_LEFT && click != ClickType.SHIFT_RIGHT) {
            return;
        }

        if (raw == MultiChestHolder.PREVIOUS_SLOT) {
            navigate(player, holder, -1);
            return;
        }
        if (raw == MultiChestHolder.NEXT_SLOT) {
            navigate(player, holder, 1);
            return;
        }
        if (raw >= MultiChestHolder.ITEM_SLOTS) return;

        int index = holder.getPage() * MultiChestHolder.ITEM_SLOTS + raw;
        StoredChest chest = holder.getChest();
        ItemStack cursor = player.getItemOnCursor();

        if (cursor.getType().isAir()) {
            withdraw(player, chest, index, click.isRightClick());
        } else if (plugin.isDisplayItem(cursor)) {
            player.setItemOnCursor(null);
        } else {
            deposit(player, chest, index, cursor, click.isRightClick());
        }
    }

    private void navigate(Player player, MultiChestHolder holder, int delta) {
        int target = holder.getPage() + delta;
        if (target < 0) {
            plugin.actionBar(player, "Ini sudah halaman pertama.", NamedTextColor.YELLOW);
            return;
        }
        if (target >= plugin.getPageCount(holder.getChest())) {
            plugin.actionBar(player, "Ini sudah halaman terakhir.", NamedTextColor.YELLOW);
            return;
        }
        plugin.scheduleOpen(player, holder.getChest(), target);
    }

    // ================================================================== transfer item

    private void deposit(Player player, StoredChest chest, int index, ItemStack cursor, boolean single) {
        int have = cursor.getAmount();
        long want = single ? 1L : have;

        long accepted = chest.deposit(index, cursor, want, plugin.getMaxPerSlot());
        if (accepted <= 0) {
            plugin.actionBar(player, "Slot penuh atau item tidak dapat disimpan.", NamedTextColor.RED);
            return;
        }

        int remain = have - (int) accepted;
        if (remain <= 0) {
            player.setItemOnCursor(null);
        } else {
            ItemStack rest = cursor.clone();
            rest.setAmount(remain);
            player.setItemOnCursor(rest);
        }

        plugin.markDirty();
        plugin.refreshSlot(chest, index);
    }

    private void withdraw(Player player, StoredChest chest, int index, boolean half) {
        SlotData slot = chest.getSlot(index);
        if (slot == null || slot.isEmpty()) return;

        long target = half ? Math.max(1L, slot.getTotal() / 2) : slot.getTotal();
        long moved = 0;
        boolean inventoryFull = false;

        for (ItemStackData data : new ArrayList<>(slot.getItems())) {
            if (target <= 0) break;
            if (!data.isReadable()) continue;

            long want = Math.min(target, data.getAmount());
            long given = give(player, data, want);
            if (given > 0) {
                slot.remove(data, given); // langsung dikurangi setelah diberikan
                target -= given;
                moved += given;
            }
            if (given < want) {
                inventoryFull = true;
                break;
            }
        }

        chest.cleanup(index);
        if (moved > 0) {
            plugin.markDirty();
            plugin.refreshSlot(chest, index);
        }
        if (inventoryFull) {
            plugin.actionBar(player, "Inventory penuh, sisa item tetap di chest.", NamedTextColor.RED);
        }
    }

    /** Memberi item ke inventory pemain. Mengembalikan jumlah yang benar-benar masuk. */
    private long give(Player player, ItemStackData data, long want) {
        int maxStack = data.getMaxStackSize();
        long remaining = want;

        while (remaining > 0) {
            int size = (int) Math.min(maxStack, remaining);
            Map<Integer, ItemStack> leftover = player.getInventory().addItem(data.createStack(size));
            if (!leftover.isEmpty()) {
                int notFit = 0;
                for (ItemStack stack : leftover.values()) notFit += stack.getAmount();
                remaining -= (size - notFit);
                break;
            }
            remaining -= size;
        }
        return want - remaining;
    }

    /** Shift-klik item dari inventory pemain: simpan ke halaman GUI yang sedang dibuka. */
    private void quickDeposit(InventoryClickEvent event, Player player, MultiChestHolder holder) {
        ItemStack current = event.getCurrentItem();
        if (current == null || current.getType().isAir() || plugin.isDisplayItem(current)) return;

        StoredChest chest = holder.getChest();
        int first = holder.getPage() * MultiChestHolder.ITEM_SLOTS;
        long max = plugin.getMaxPerSlot();
        long original = current.getAmount();
        long remaining = original;

        // Tahap 1: slot yang sudah berisi jenis item yang sama.
        for (int i = 0; i < MultiChestHolder.ITEM_SLOTS && remaining > 0; i++) {
            int index = first + i;
            SlotData slot = chest.getSlot(index);
            if (slot == null || !slot.contains(current)) continue;
            long moved = chest.deposit(index, current, remaining, max);
            if (moved > 0) {
                remaining -= moved;
                plugin.refreshSlot(chest, index);
            }
        }

        // Tahap 2: slot kosong.
        for (int i = 0; i < MultiChestHolder.ITEM_SLOTS && remaining > 0; i++) {
            int index = first + i;
            if (chest.getSlot(index) != null) continue;
            long moved = chest.deposit(index, current, remaining, max);
            if (moved <= 0) break;
            remaining -= moved;
            plugin.refreshSlot(chest, index);
        }

        if (remaining == original) {
            plugin.actionBar(player, "Halaman ini penuh.", NamedTextColor.RED);
            return;
        }

        if (remaining <= 0) {
            event.setCurrentItem(null);
        } else {
            ItemStack rest = current.clone();
            rest.setAmount((int) remaining);
            event.setCurrentItem(rest);
        }
        plugin.markDirty();
    }

    // ================================================================== proteksi chest terdaftar

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() != Material.CHEST) return;
        StoredChest chest = plugin.getChest(block);
        if (chest == null) return;

        if (!chest.isEmpty()) {
            event.setCancelled(true);
            plugin.message(event.getPlayer(),
                    "MultiChest ini masih berisi item. Kosongkan dulu sebelum dihancurkan.", NamedTextColor.RED);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onBreakDone(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (block.getType() != Material.CHEST) return;
        StoredChest chest = plugin.getChest(block);
        if (chest != null && chest.isEmpty()) plugin.unregister(block);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityExplode(EntityExplodeEvent event) {
        protect(event.blockList());
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent event) {
        protect(event.blockList());
    }

    private void protect(List<Block> blocks) {
        if (!plugin.hasChests()) return;
        blocks.removeIf(block -> block.getType() == Material.CHEST && plugin.getChest(block) != null);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (!plugin.hasChests()) return;
        Block block = event.getBlock();
        if (block.getType() == Material.CHEST && plugin.getChest(block) != null) {
            event.setCancelled(true);
        }
    }

    /** Mencegah chest di sebelah chest terdaftar menyatu menjadi double chest. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!plugin.hasChests()) return;
        Block placed = event.getBlockPlaced();
        if (placed.getType() != Material.CHEST) return;

        for (BlockFace face : HORIZONTAL) {
            Block neighbor = placed.getRelative(face);
            if (neighbor.getType() == Material.CHEST && plugin.getChest(neighbor) != null) {
                event.setCancelled(true);
                plugin.message(event.getPlayer(),
                        "Tidak bisa menaruh chest tepat di sebelah MultiChest.", NamedTextColor.RED);
                return;
            }
        }
    }

    /** Hopper tidak boleh memasukkan/mengambil item dari chest asli milik MultiChest. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHopperMove(InventoryMoveItemEvent event) {
        if (!plugin.isBlockHoppers() || !plugin.hasChests()) return;
        if (isRegisteredChest(event.getDestination()) || isRegisteredChest(event.getSource())) {
            event.setCancelled(true);
        }
    }

    private boolean isRegisteredChest(Inventory inventory) {
        if (inventory.getType() != InventoryType.CHEST) return false;
        Location location = inventory.getLocation();
        return location != null && plugin.getChest(location) != null;
    }
}
