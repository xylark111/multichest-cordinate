package com.example.multichest;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

public final class MultiChestPlugin extends JavaPlugin {

    // Semua akses ke data chest hanya dari main thread. Thread penulis hanya menerima snapshot immutable.
    private final Map<StoredChest.Key, StoredChest> chests = new HashMap<>();
    private final Set<MultiChestHolder> openHolders = Collections.newSetFromMap(new IdentityHashMap<>());

    private final AtomicBoolean dirty = new AtomicBoolean(false);
    private final AtomicLong sequence = new AtomicLong();
    private final Object fileLock = new Object();
    private long lastWritten = 0; // dijaga fileLock

    private ExecutorService writer;
    private BukkitTask saveTask;
    private NamespacedKey markerKey;
    private File dataFile;
    private boolean dataLoaded = false;

    private long maxPerSlot = 54;
    private int maxPages = 20;
    private int saveIntervalTicks = 40;
    private boolean blockHoppers = true;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        readConfig();

        markerKey = new NamespacedKey(this, "display");
        getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "chests.yml");

        try {
            chests.putAll(readData());
        } catch (Exception ex) {
            getLogger().severe("Gagal membaca chests.yml: " + ex.getMessage());
            getLogger().severe("Plugin dimatikan agar data tidak tertimpa. Perbaiki file lalu restart.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        dataLoaded = true;

        writer = Executors.newSingleThreadExecutor(r -> {
            Thread thread = new Thread(r, "MultiChest-Writer");
            thread.setDaemon(true);
            return thread;
        });

        getServer().getPluginManager().registerEvents(new ChestListener(this), this);
        PluginCommand command = getCommand("multichest");
        if (command != null) {
            ChestCommand handler = new ChestCommand(this);
            command.setExecutor(handler);
            command.setTabCompleter(handler);
        }

        startSaveTask();
        getLogger().info("MultiChest aktif. Chest terdaftar: " + chests.size());
    }

    @Override
    public void onDisable() {
        if (!dataLoaded) return;
        if (saveTask != null) saveTask.cancel();
        closeAllViewers();
        writer.shutdown();
        try {
            writer.awaitTermination(10, TimeUnit.SECONDS);
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
        flushNow();
    }

    // ------------------------------------------------------------------ config

    private void readConfig() {
        maxPerSlot = Math.max(1L, Math.min(100_000_000L, getConfig().getLong("max-per-slot", 54L)));
        maxPages = Math.max(1, Math.min(1000, getConfig().getInt("max-pages", 20)));
        int seconds = Math.max(1, getConfig().getInt("save-interval-seconds", 2));
        saveIntervalTicks = seconds * 20;
        blockHoppers = getConfig().getBoolean("block-hoppers", true);
    }

    private void startSaveTask() {
        if (saveTask != null) saveTask.cancel();
        saveTask = getServer().getScheduler().runTaskTimer(this, () -> {
            if (dirty.compareAndSet(true, false)) submitSnapshot();
        }, saveIntervalTicks, saveIntervalTicks);
    }

    public long getMaxPerSlot() {
        return maxPerSlot;
    }

    public boolean isBlockHoppers() {
        return blockHoppers;
    }

    public int getPageCount(StoredChest chest) {
        return Math.max(maxPages, chest.getHighestPage() + 1);
    }

    // ------------------------------------------------------------------ registry

    public boolean hasChests() {
        return !chests.isEmpty();
    }

    public Collection<StoredChest> getChests() {
        return Collections.unmodifiableCollection(chests.values());
    }

    public StoredChest getChest(Block block) {
        if (chests.isEmpty()) return null;
        return chests.get(StoredChest.Key.of(block));
    }

    public StoredChest getChest(Location location) {
        if (chests.isEmpty() || location.getWorld() == null) return null;
        return chests.get(new StoredChest.Key(location.getWorld().getName(),
                location.getBlockX(), location.getBlockY(), location.getBlockZ()));
    }

    public boolean isRegistered(Block block) {
        return getChest(block) != null;
    }

    public boolean register(Block block) {
        StoredChest.Key key = StoredChest.Key.of(block);
        if (chests.containsKey(key)) return false;
        chests.put(key, new StoredChest(key));
        markDirty();
        return true;
    }

    public boolean unregister(Block block) {
        StoredChest removed = chests.remove(StoredChest.Key.of(block));
        if (removed == null) return false;
        closeViewers(removed);
        markDirty();
        return true;
    }

    // ------------------------------------------------------------------ GUI

    public void openGui(Player player, StoredChest chest, int page) {
        if (chests.get(chest.getKey()) != chest) return;
        int clamped = Math.max(0, Math.min(page, getPageCount(chest) - 1));
        player.openInventory(new MultiChestHolder(this, chest, clamped).getInventory());
    }

    /** Membuka GUI di tick berikutnya (aman dipanggil dari dalam InventoryClickEvent). */
    public void scheduleOpen(Player player, StoredChest chest, int page) {
        getServer().getScheduler().runTask(this, () -> {
            if (player.isOnline()) openGui(player, chest, page);
        });
    }

    public void trackOpen(MultiChestHolder holder) {
        openHolders.add(holder);
    }

    public void trackClose(MultiChestHolder holder) {
        openHolders.remove(holder);
    }

    public void refreshSlot(StoredChest chest, int index) {
        for (MultiChestHolder holder : openHolders) {
            if (holder.getChest() == chest) holder.refresh(index);
        }
    }

    public void closeViewers(StoredChest chest) {
        for (MultiChestHolder holder : new ArrayList<>(openHolders)) {
            if (holder.getChest() != chest) continue;
            for (HumanEntity viewer : new ArrayList<>(holder.getInventory().getViewers())) {
                viewer.closeInventory();
            }
        }
    }

    public void closeAllViewers() {
        for (MultiChestHolder holder : new ArrayList<>(openHolders)) {
            for (HumanEntity viewer : new ArrayList<>(holder.getInventory().getViewers())) {
                viewer.closeInventory();
            }
        }
        openHolders.clear();
    }

    // ------------------------------------------------------------------ marker (item tampilan GUI)

    public void markDisplay(ItemMeta meta) {
        meta.getPersistentDataContainer().set(markerKey, PersistentDataType.BYTE, (byte) 1);
    }

    public boolean isDisplayItem(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return false;
        return stack.getItemMeta().getPersistentDataContainer().has(markerKey, PersistentDataType.BYTE);
    }

    // ------------------------------------------------------------------ pesan

    public void message(CommandSender to, String text, NamedTextColor color) {
        to.sendMessage(Component.text(text, color));
    }

    public void actionBar(Player to, String text, NamedTextColor color) {
        to.sendActionBar(Component.text(text, color));
    }

    // ------------------------------------------------------------------ reload

    public boolean reloadAll() {
        closeAllViewers();
        if (!flushNow()) return false;
        reloadConfig();
        readConfig();
        startSaveTask();
        try {
            Map<StoredChest.Key, StoredChest> loaded = readData();
            chests.clear();
            chests.putAll(loaded);
            return true;
        } catch (Exception ex) {
            getLogger().severe("Gagal memuat ulang chests.yml: " + ex.getMessage());
            return false;
        }
    }

    // ------------------------------------------------------------------ persistence

    public void markDirty() {
        dirty.set(true);
    }

    private Map<StoredChest.Key, StoredChest> readData() throws IOException, InvalidConfigurationException {
        Map<StoredChest.Key, StoredChest> result = new HashMap<>();
        if (!dataFile.exists()) return result;

        YamlConfiguration yaml = new YamlConfiguration();
        try {
            yaml.load(dataFile);
        } catch (IOException | InvalidConfigurationException ex) {
            File backup = new File(getDataFolder(), "chests.corrupt-" + System.currentTimeMillis() + ".yml");
            Files.copy(dataFile.toPath(), backup.toPath());
            throw ex;
        }

        ConfigurationSection root = yaml.getConfigurationSection("chests");
        if (root == null) return result;

        for (String id : root.getKeys(false)) {
            ConfigurationSection section = root.getConfigurationSection(id);
            if (section == null) continue;

            String world = section.getString("world");
            if (world == null) {
                getLogger().warning("Entri chest '" + id + "' tanpa world, dilewati.");
                continue;
            }

            StoredChest chest = new StoredChest(new StoredChest.Key(world,
                    section.getInt("x"), section.getInt("y"), section.getInt("z")));

            ConfigurationSection slotsSection = section.getConfigurationSection("slots");
            if (slotsSection != null) {
                for (String slotId : slotsSection.getKeys(false)) {
                    ConfigurationSection slotSection = slotsSection.getConfigurationSection(slotId);
                    if (slotSection == null) continue;

                    int index = slotSection.getInt("page", 0) * MultiChestHolder.ITEM_SLOTS
                            + slotSection.getInt("slot", 0);
                    SlotData slot = new SlotData();

                    for (Map<?, ?> raw : slotSection.getMapList("items")) {
                        Object encoded = raw.get("data");
                        Object amountObj = raw.get("amount");
                        if (!(encoded instanceof String) || !(amountObj instanceof Number)) continue;
                        long amount = ((Number) amountObj).longValue();
                        if (amount <= 0) continue;

                        ItemStackData data = ItemStackData.fromEncoded((String) encoded, amount);
                        if (!data.isReadable()) {
                            getLogger().warning("Item tidak terbaca di chest " + chest.getKey()
                                    + " (slot " + index + "); data mentah tetap disimpan.");
                        }
                        slot.addLoaded(data);
                    }
                    if (!slot.isEmpty()) chest.putSlot(index, slot);
                }
            }
            result.put(chest.getKey(), chest);
        }
        return result;
    }

    /** Dipanggil di main thread. Membangun snapshot ringan; encoding Base64 sudah di-cache per item. */
    private Map<String, Object> buildSnapshot() {
        Map<String, Object> root = new LinkedHashMap<>();
        int counter = 0;
        for (StoredChest chest : chests.values()) {
            Map<String, Object> chestMap = new LinkedHashMap<>();
            chestMap.put("world", chest.getKey().world());
            chestMap.put("x", chest.getKey().x());
            chestMap.put("y", chest.getKey().y());
            chestMap.put("z", chest.getKey().z());

            Map<String, Object> slotsMap = new LinkedHashMap<>();
            for (Map.Entry<Integer, SlotData> entry : new TreeMap<>(chest.getSlots()).entrySet()) {
                int index = entry.getKey();
                Map<String, Object> slotMap = new LinkedHashMap<>();
                slotMap.put("page", index / MultiChestHolder.ITEM_SLOTS);
                slotMap.put("slot", index % MultiChestHolder.ITEM_SLOTS);

                List<Map<String, Object>> items = new ArrayList<>();
                for (ItemStackData data : entry.getValue().getItems()) {
                    Map<String, Object> itemMap = new LinkedHashMap<>();
                    itemMap.put("data", data.getEncoded());
                    itemMap.put("amount", data.getAmount());
                    items.add(itemMap);
                }
                slotMap.put("items", items);
                slotsMap.put("s" + index, slotMap);
            }
            chestMap.put("slots", slotsMap);
            root.put("c" + counter++, chestMap);
        }
        return root;
    }

    private void submitSnapshot() {
        if (writer == null || writer.isShutdown()) return;
        long seq = sequence.incrementAndGet();
        Map<String, Object> snapshot = buildSnapshot();
        writer.execute(() -> writeSnapshot(seq, snapshot));
    }

    private boolean flushNow() {
        long seq = sequence.incrementAndGet();
        boolean ok = writeSnapshot(seq, buildSnapshot());
        if (ok) dirty.set(false);
        return ok;
    }

    /** Menulis ke temp file lalu memindahkan secara atomik; snapshot lama tidak menimpa yang baru. */
    private boolean writeSnapshot(long seq, Map<String, Object> snapshot) {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.createSection("chests", snapshot);
        String text = yaml.saveToString();

        synchronized (fileLock) {
            if (seq <= lastWritten) return true;
            try {
                Path target = dataFile.toPath();
                Path temp = target.resolveSibling("chests.yml.tmp");
                Files.writeString(temp, text, StandardCharsets.UTF_8);
                try {
                    Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException ex) {
                    Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
                }
                lastWritten = seq;
                return true;
            } catch (IOException ex) {
                getLogger().severe("Gagal menyimpan chests.yml: " + ex.getMessage());
                dirty.set(true);
                return false;
            }
        }
    }
}
