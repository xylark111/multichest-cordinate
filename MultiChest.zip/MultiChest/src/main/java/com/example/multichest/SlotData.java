package com.example.multichest;

import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Satu slot virtual: boleh berisi beberapa jenis item, total dibatasi max-per-slot. */
public final class SlotData {

    private final List<ItemStackData> items = new ArrayList<>();
    private long total;

    public long getTotal() {
        return total;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public List<ItemStackData> getItems() {
        return Collections.unmodifiableList(items);
    }

    /** Dipakai saat load dari file. */
    public void addLoaded(ItemStackData data) {
        items.add(data);
        total += data.getAmount();
    }

    public boolean contains(ItemStack stack) {
        return find(stack) != null;
    }

    private ItemStackData find(ItemStack stack) {
        for (ItemStackData data : items) {
            if (data.matches(stack)) return data;
        }
        return null;
    }

    /**
     * Menambah item ke slot. Mengembalikan jumlah yang benar-benar diterima
     * (0 jika penuh atau item tidak bisa disimpan). Tidak mengubah stack asal.
     */
    public long add(ItemStack stack, long amount, long max) {
        long accepted = Math.min(amount, max - total);
        if (accepted <= 0) return 0;

        ItemStackData target = find(stack);
        if (target != null) {
            target.add(accepted);
        } else {
            ItemStackData created = ItemStackData.create(stack, accepted);
            if (created == null) return 0;
            items.add(created);
        }
        total += accepted;
        return accepted;
    }

    public void remove(ItemStackData data, long amount) {
        long removed = Math.min(amount, data.getAmount());
        if (removed <= 0) return;
        data.remove(removed);
        total -= removed;
        if (data.getAmount() <= 0) items.remove(data);
    }

    public ItemStackData getLargestReadable() {
        ItemStackData best = null;
        for (ItemStackData data : items) {
            if (!data.isReadable()) continue;
            if (best == null || data.getAmount() > best.getAmount()) best = data;
        }
        return best;
    }
}
