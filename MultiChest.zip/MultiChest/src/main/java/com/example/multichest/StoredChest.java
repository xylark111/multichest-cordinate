package com.example.multichest;

import org.bukkit.block.Block;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

/** Data satu chest terdaftar: lokasi + slot virtual (index absolut = halaman * 45 + slot). */
public final class StoredChest {

    public record Key(String world, int x, int y, int z) {
        public static Key of(Block block) {
            return new Key(block.getWorld().getName(), block.getX(), block.getY(), block.getZ());
        }
    }

    private final Key key;
    private final Map<Integer, SlotData> slots = new HashMap<>();

    public StoredChest(Key key) {
        this.key = key;
    }

    public Key getKey() {
        return key;
    }

    public Map<Integer, SlotData> getSlots() {
        return slots;
    }

    public SlotData getSlot(int index) {
        return slots.get(index);
    }

    public void putSlot(int index, SlotData slot) {
        slots.put(index, slot);
    }

    /** Menaruh item ke slot virtual. Mengembalikan jumlah yang diterima. */
    public long deposit(int index, ItemStack stack, long amount, long max) {
        SlotData slot = slots.get(index);
        boolean created = false;
        if (slot == null) {
            slot = new SlotData();
            created = true;
        }
        long accepted = slot.add(stack, amount, max);
        if (accepted > 0 && created) slots.put(index, slot);
        return accepted;
    }

    /** Menghapus slot dari map jika sudah kosong. */
    public void cleanup(int index) {
        SlotData slot = slots.get(index);
        if (slot != null && slot.isEmpty()) slots.remove(index);
    }

    public boolean isEmpty() {
        return slots.isEmpty();
    }

    public long getTotalItems() {
        long sum = 0;
        for (SlotData slot : slots.values()) sum += slot.getTotal();
        return sum;
    }

    public int getHighestPage() {
        int highest = 0;
        for (int index : slots.keySet()) {
            highest = Math.max(highest, index / MultiChestHolder.ITEM_SLOTS);
        }
        return highest;
    }
}
