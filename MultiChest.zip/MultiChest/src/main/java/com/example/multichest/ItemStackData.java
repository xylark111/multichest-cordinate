package com.example.multichest;

import org.bukkit.inventory.ItemStack;

import java.util.Base64;

/**
 * Satu jenis item (prototype, amount 1) beserta jumlahnya di dalam slot virtual.
 * Disimpan sebagai Base64 dari ItemStack#serializeAsBytes (mencakup meta, enchant, NBT, dll).
 * Jika item gagal dibaca saat load, data mentah tetap dipertahankan agar tidak hilang.
 */
public final class ItemStackData {

    private final ItemStack prototype; // null jika tidak terbaca
    private final String encoded;
    private long amount;

    private ItemStackData(ItemStack prototype, String encoded, long amount) {
        this.prototype = prototype;
        this.encoded = encoded;
        this.amount = amount;
    }

    /** Membuat data baru dari item. Mengembalikan null jika item tidak bisa diserialisasi. */
    public static ItemStackData create(ItemStack source, long amount) {
        try {
            ItemStack proto = source.clone();
            proto.setAmount(1);
            String enc = Base64.getEncoder().encodeToString(proto.serializeAsBytes());
            return new ItemStackData(proto, enc, amount);
        } catch (RuntimeException ex) {
            return null;
        }
    }

    /** Membuat data dari hasil load. Jika gagal dibaca, data mentah tetap disimpan. */
    public static ItemStackData fromEncoded(String encoded, long amount) {
        try {
            ItemStack proto = ItemStack.deserializeBytes(Base64.getDecoder().decode(encoded));
            if (proto == null || proto.getType().isAir()) {
                return new ItemStackData(null, encoded, amount);
            }
            proto.setAmount(1);
            return new ItemStackData(proto, encoded, amount);
        } catch (RuntimeException ex) {
            return new ItemStackData(null, encoded, amount);
        }
    }

    public boolean isReadable() {
        return prototype != null;
    }

    public ItemStack getPrototype() {
        return prototype;
    }

    public String getEncoded() {
        return encoded;
    }

    public long getAmount() {
        return amount;
    }

    void add(long value) {
        amount += value;
    }

    void remove(long value) {
        amount -= value;
    }

    public boolean matches(ItemStack other) {
        return prototype != null && prototype.isSimilar(other);
    }

    public int getMaxStackSize() {
        return prototype == null ? 1 : Math.max(1, prototype.getMaxStackSize());
    }

    public ItemStack createStack(int size) {
        ItemStack stack = prototype.clone();
        stack.setAmount(size);
        return stack;
    }
}
