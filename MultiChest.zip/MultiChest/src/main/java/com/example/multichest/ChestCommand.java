package com.example.multichest;

import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ChestCommand implements TabExecutor {

    private static final String USAGE = "/multichest <add|remove|list|reload>";

    private final MultiChestPlugin plugin;

    public ChestCommand(MultiChestPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("multichest.use")) {
            plugin.message(sender, "Kamu tidak punya izin (multichest.use).", NamedTextColor.RED);
            return true;
        }
        if (args.length == 0) {
            plugin.message(sender, "Gunakan: " + USAGE, NamedTextColor.YELLOW);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "add" -> add(sender);
            case "remove" -> remove(sender, args.length > 1 && args[1].equalsIgnoreCase("force"));
            case "list" -> list(sender);
            case "reload" -> {
                if (plugin.reloadAll()) {
                    plugin.message(sender, "Config dan data chest berhasil dimuat ulang.", NamedTextColor.GREEN);
                } else {
                    plugin.message(sender, "Reload gagal, lihat console. Data lama tetap dipakai.", NamedTextColor.RED);
                }
            }
            default -> plugin.message(sender, "Gunakan: " + USAGE, NamedTextColor.YELLOW);
        }
        return true;
    }

    private Block targetChest(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            plugin.message(sender, "Perintah ini hanya bisa dipakai pemain.", NamedTextColor.RED);
            return null;
        }
        Block target = player.getTargetBlockExact(6);
        if (target == null || target.getType() != Material.CHEST) {
            plugin.message(sender, "Kamu harus melihat sebuah chest (maksimal 6 blok).", NamedTextColor.RED);
            return null;
        }
        return target;
    }

    private void add(CommandSender sender) {
        Block target = targetChest(sender);
        if (target == null) return;

        if (plugin.isRegistered(target)) {
            plugin.message(sender, "Chest ini sudah terdaftar.", NamedTextColor.YELLOW);
            return;
        }

        BlockState state = target.getState(false);
        if (!(state instanceof Chest chestState)) {
            plugin.message(sender, "Block ini bukan chest.", NamedTextColor.RED);
            return;
        }
        if (chestState.getInventory().getSize() != 27) {
            plugin.message(sender, "Double chest tidak bisa didaftarkan. Pakai chest tunggal.", NamedTextColor.RED);
            return;
        }
        if (!chestState.getBlockInventory().isEmpty()) {
            plugin.message(sender, "Kosongkan chest dulu sebelum didaftarkan agar tidak ada item yang hilang.",
                    NamedTextColor.RED);
            return;
        }

        plugin.register(target);
        plugin.message(sender, "Chest di " + target.getWorld().getName() + " " + target.getX() + ", "
                + target.getY() + ", " + target.getZ() + " berhasil didaftarkan.", NamedTextColor.GREEN);
    }

    private void remove(CommandSender sender, boolean force) {
        Block target = targetChest(sender);
        if (target == null) return;

        StoredChest chest = plugin.getChest(target);
        if (chest == null) {
            plugin.message(sender, "Chest ini belum terdaftar.", NamedTextColor.YELLOW);
            return;
        }
        if (!chest.isEmpty() && !force) {
            plugin.message(sender, "Chest masih berisi " + chest.getTotalItems()
                    + " item. Ambil semua dulu, atau pakai /multichest remove force "
                    + "(SEMUA ISI AKAN HILANG PERMANEN).", NamedTextColor.RED);
            return;
        }

        plugin.unregister(target);
        plugin.message(sender, "Pendaftaran chest ini dihapus.", NamedTextColor.GREEN);
    }

    private void list(CommandSender sender) {
        plugin.message(sender, "Chest terdaftar (" + plugin.getChests().size() + "):", NamedTextColor.GOLD);
        int shown = 0;
        for (StoredChest chest : plugin.getChests()) {
            if (shown++ >= 50) {
                plugin.message(sender, "... dan " + (plugin.getChests().size() - 50) + " lainnya.",
                        NamedTextColor.GRAY);
                break;
            }
            StoredChest.Key key = chest.getKey();
            plugin.message(sender, "- " + key.world() + " " + key.x() + ", " + key.y() + ", " + key.z()
                    + " (" + chest.getTotalItems() + " item)", NamedTextColor.GRAY);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (!sender.hasPermission("multichest.use")) return result;

        if (args.length == 1) {
            for (String option : List.of("add", "remove", "list", "reload")) {
                if (option.startsWith(args[0].toLowerCase(Locale.ROOT))) result.add(option);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("remove") && "force".startsWith(args[1].toLowerCase(Locale.ROOT))) {
            result.add("force");
        }
        return result;
    }
}
